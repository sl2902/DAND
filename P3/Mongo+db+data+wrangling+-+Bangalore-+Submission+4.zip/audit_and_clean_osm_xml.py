# -*- coding: utf-8 -*-
"""
Created on Sun Aug 21 12:29:30 2016

@author: sl

The sketal of this code was provided by Udacity and improved upon in the Open case study phase. 
Further, I have tweaked or added new functions whereever required

The script harmonizes the street and post codes and creates the shape element file suitable 
for importing into Mongo DB

"""

import xml.etree.cElementTree as ET
from collections import defaultdict
import re
import pprint
import codecs
import json
import os
import sys
#sys.path.append(r'W:/udacity/DAND')
#import osmmodules as osm


path = r'W:/Udacity/DAND'
lower = re.compile(r'^([a-z]|_)*$')
lower_colon = re.compile(r'^([a-z]|_)*:([a-z]|_)*$')
problemchars = re.compile(r'[=\+/&<>;\'"\?%#$@\,\. \t\r\n]')
double_colon = re.compile(r'^\w+:\w+:\w+$')
FIELDS = {
    "id": "id",
    "visible": "visible",
    "amenity": "amenity",
    "cuisine": "cuisine",
    "name": "name",
    "phone": "phone"
    }

# UPDATE THIS VARIABLE
mapping = {"St.": "Street",
           "Rd.": "Road",
           "Rd": "Road",
           "Rd,": "Road",
           "Raod": "Road",
           "Road,":"Road",
           "Road)": "Road",
           "indl": "Industrial"
           }

CREATED = [ "version", "changeset", "timestamp", "user", "uid"]
ADDR = ['housenumber', 'postcode', 'street']
expected = ["Street", "Avenue", "Court", "Lane", "Road", 
            "Main", "Cross", "Layout", "Sector", "Stage",
           "Phase", "Block"]

street_type_re = re.compile(r'\b\S+\.?$', re.IGNORECASE)

def clean_postcodes(subtag_value):
    '''
    Takes a subtag value for the corresponding addr:postcode tag
    and checks for space and size. Removes space and any extraneous
    digits to meet postcode size rules. Postcodes of size < 6 are passed as is
    
    Input: string type - uncleaned postcode
    Returns the cleaned postcode whereever possible, otherwise
    returns the uncleaned postcode as is
    '''
    space_re = re.compile(r'\D+|\d{7,}')
    cleaned_postcode = ''
    if space_re.search(subtag_value):
        cleaned_postcode = re.sub(r'\D+', '', subtag_value)
        if len(cleaned_postcode) <= 6:
            return cleaned_postcode
        return cleaned_postcode[:-1]
    return subtag_value

def audit_street_type(street_types, street_name):
    """
    Audits street addresses and builds a dictionary
    of unexpected street names
    
    Input: A dictionary to store the unexpected street names and the street name, 
            which is a string
    """        
    m = street_type_re.search(street_name)
    if m:
        street_type = m.group()
        if street_type not in expected:
            street_types[street_type].add(street_name)
            
def update_name(name, mapping):
    """
    Replace abbreviated street names by mapping them to the correct values
    
    Input: A string, which is a street name and a dictionary containing
            the corrected street names
    Output: The corrected street name if present in the mapping dictionary
            otherwise returns the uncleaned street name as is
    """
    m = street_type_re.search(name)
    if m:
        street_type = m.group()
        if street_type in mapping:
            return name.replace(street_type, mapping[street_type])
    return name            

def shape_element(element):
    """
    Parses every element in the OSM XML file and returns a dictionary
    of a subset of selected fields
    
    Input: XML element
    Output: A dictionary
    """
    
    node = {}
    node['created'] = {}
    node['pos'] = []
    node_refs = []
    addr_ext = ''
    street_types = defaultdict(set)
    
    if element.tag == "node" or element.tag == "way" :
        for k, v in element.attrib.iteritems():
            if k in FIELDS:
                node[k] = v
            elif k == 'lat' or k == 'lon':
                # this is so, because lat should appear in first position in the final dictionary
                if k == 'lat':
                    node['pos'].insert(0, float(v))
                else:
                    node['pos'].append(float(v))
            elif k in CREATED:
                node['created'][k] = v
        node["type"] = element.tag
        # iterate over tag elements
        for subtag in element.iter("tag"):
            if problemchars.search(subtag.get('k')) or double_colon.search(subtag.get('k')):
#                print 'problem tags:', subtag.get('k'), subtag.get('v')
                continue
            # some tags start with address instead of addr:
            elif subtag.get('k').startswith('addr:'):
                if not 'address' in node:
                    node['address'] = {}
                try:
                    addr_ext = subtag.get('k').split(':')[1]
                except:
                    print 'Incorrect tag format for addr:street'
                    print subtag.get('k')
                if addr_ext in ADDR:
                    # clean street addresses that can be fixed
                    audit_street_type(street_types, subtag.attrib['v'])
                    if addr_ext == 'street' and len(street_types) > 0:
                        for st_type, ways in street_types.iteritems():
                            for name in ways:
                                node['address'][addr_ext] = update_name(name, mapping) 
                    else:
                        if subtag.get('k') == 'addr:postcode':
                            node['address'][addr_ext] = clean_postcodes(subtag.get('v'))
                        else:
                            node['address'][addr_ext] = subtag.get('v')
#                        if subtag.get('k') == 'addr:postcode':
#                            print subtag.get('v')
            elif subtag.get('k') in FIELDS:
                node[subtag.get('k')] = subtag.get('v')
#                if subtag.get('k') == 'name':
#                    print subtag.get('v')
        # iterate over nd elements
        for subtag in element.iter("nd"):
            node_refs.append(subtag.get('ref'))
        if node_refs:
            node["node_refs"] = node_refs

        return node
    else:
        return None


def process_map(file_in, pretty = False):
    """
    Creates a JSON file from the parsed elements
    Input: Filename of the OSM XML
    Output: A JSON file
    """
    # strip the .osm from the input file
    file_in_strip_ext = file_in.split('.')[0]
    file_out = "{0}.json".format(file_in_strip_ext)
    data = []
    with codecs.open(os.path.join(path, file_out), "w", 'utf-8') as fo:
        for _, element in ET.iterparse(file_in):
            el = shape_element(element)
            if el:
                data.append(el)
                if pretty:
                    fo.write(json.dumps(el, indent=2)+"\n")
                else:
                    fo.write(json.dumps(el) + "\n")
    return data

def test():
    # NOTE: if you are running this code on your computer, with a larger dataset, 
    # call the process_map procedure with pretty=False. The pretty=True option adds 
    # additional spaces to the output, making it significantly larger.
#    OSM_FILE = 'Bng_sample.osm'
    OSM_FILE = 'bengaluru_india.osm'
    filename = os.path.join(path, OSM_FILE)
    data = process_map(filename, False)
    #pprint.pprint(data)
    


if __name__ == "__main__":
    test()