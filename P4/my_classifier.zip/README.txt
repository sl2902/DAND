poi_exploratory_analysis.py
This script was developed to do some exploratory analysis to gain
some intuition about the data

poi_id.py
This script was used to develop the Decision Tree Classifier
It has code to also run the Gaussian Naive Bayes and Random
Forest Classifier. But to run them, you will need to uncomment
the lines before running them. But be warned, that the Random
Forest Classifier runs for more than 3 hours. 
To test the script including PCA, you will need to replace the 
value in the use_pca variable to True
To try out various combinations of using MinMaxScaler/SelectKBest
you will need to comment/uncomment code in method buid_pipe()