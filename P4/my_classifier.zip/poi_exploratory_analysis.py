
# coding: utf-8

# In[37]:

import sys
import os
import pickle
sys.path.append("../tools/")
import pandas as pd
import numpy as np

#from feature_format import featureFormat, targetFeatureSplit
#from tester import dump_classifier_and_data


# In[33]:

path = r'W:\Udacity\DAND\Intro to Machine Learning\ud120-projects-master\python nb'
with open(os.path.join(path, "final_project_dataset.pkl"), "r") as data_file:
    data_dict = pickle.load(data_file)
#    poi_df = pd.DataFrame.from_dict(data_dict, orient='index').reset_index().rename(columns = {'index': 'poi_name'})
    poi_df = pd.DataFrame(data_dict).T.reset_index().rename(columns = {'index': 'poi_name'})
poi_df.head()    


# In[113]:

pd.set_option('display.max_columns', None
poi_df.T.head()


# Size of the dataset

# In[34]:

poi_df.shape


# Get list of features

# In[35]:

list(poi_df.columns)


# Check dtypes of features

# In[41]:

poi_df.dtypes


# In[ ]:

Except for poi, all the features are of object type. 


# Count number of NaN's against each feature

# In[40]:

def missing_values(feature):
    """
    Count number of NaNs for each feature
    Input: feature name
    Output: count of missing NaN
    """
    return sum(feature.isnull())


# In[39]:

poi_df.apply(missing_values, axis = 0)


# Since the NaN's are strings, I have to replace NaN's with ''
# 
# http://stackoverflow.com/questions/26837998/pandas-replace-nan-with-blank-empty-string

# In[45]:

feature_list = ['salary',
 'to_messages',
 'deferral_payments',
 'total_payments',
 'exercised_stock_options',
 'bonus',
 'restricted_stock',
 'shared_receipt_with_poi',
 'restricted_stock_deferred',
 'total_stock_value',
 'expenses',
 'loan_advances',
 'from_messages',
 'other',
 'from_this_person_to_poi',
 'director_fees',
 'deferred_income',
 'long_term_incentive',
 'from_poi_to_this_person']
#poi_df[feature_list].fillna('', inplace=True)
poi_new = poi_df.replace(r'NaN', np.nan, regex=True)


# Count the missing values for each feature again

# In[50]:

100 * (poi_new.apply(missing_values, axis = 0) / 146.)


# Except for poi_name and poi, all other features have missing values. But there are a few features that 
# have a significant number of missing values. I will exclude features that have at least 70% of values missing.
# These are: deferral_payments, director_fees, loan_advances, restricted_stock_deferred

# Drop the poi_name and email_address features

# In[54]:

poi_new.drop(['poi_name', 'email_address'], axis = 1, inplace = True)


# Change the dtypes to numeric for the remaining columns except poi
# 
# http://stackoverflow.com/questions/15891038/pandas-change-data-type-of-columns

# In[60]:

poi_new.apply(lambda x: pd.to_numeric(x, errors = 'ignore'))
poi_new[['poi']] = poi_new[['poi']].astype(object)
poi_new.dtypes


# Carry out some EDA. 
# 
# Look for outliers
# Plot some variable

# In[67]:

import matplotlib.pyplot as plt
get_ipython().magic(u'matplotlib inline')


# In[62]:

def range(feature, axis = 0):
    return (np.min(feature, axis = axis), np.max(feature, axis = axis))


# In[63]:

poi_new.apply(range, axis = 0)


# Scatter plot of salary vs bonus by poi
# 
# http://stackoverflow.com/questions/27711078/scatter-plots-in-pandas-pyplot-how-to-plot-by-category-with-different-markers <br>
# [remove title](http://stackoverflow.com/questions/23507229/set-no-title-for-pandas-boxplot-groupby)

# In[111]:

fig = plt.figure(figsize=(15, 6))
ax1 = fig.add_subplot(131)

groups = poi_new[['salary', 'bonus', 'poi']].groupby('poi')
for name, group in groups:
    ax1.scatter(group.salary, group.bonus, color=['blue', 'red'], marker='o', label=name)
ax1.legend(loc = 'upper left')
plt.xlabel('Salary')
plt.ylabel('Bonus')

ax2 = fig.add_subplot(132)

groups = poi_new[['from_poi_to_this_person', 'from_this_person_to_poi', 'poi']].groupby('poi')
for name, group in groups:
    ax2.scatter(group.from_poi_to_this_person, group.from_this_person_to_poi, 
                color=['blue', 'red'], marker='o', label=name)
ax2.legend(loc = 'upper right')
plt.xlabel('From poi to this person')
plt.ylabel('From this person to poi')

ax3 = fig.add_subplot(133)
poi_new.boxplot(column='salary',
                    by='poi', ax=ax3)
ax3.set_yscale('log')
plt.ylabel('Salary log 10()')
plt.suptitle('')
plt.title('')
plt.show()


# There are outliers for both the poi = 0 and poi = 1 classes. Identify the poi_name 
# corresponding to these outliers and remove them

# Based on the mini projects, we had seen some outliers with respect to poi_names such as total. So revert to original
# dataframe with features as poi_name

# In[117]:

with open(os.path.join(path, "final_project_dataset.pkl"), "r") as data_file:
    data_dict = pickle.load(data_file)
    name_df = pd.DataFrame.from_dict(data_dict, orient='columns')    


# In[138]:

name_df.shape


# Count missing features by poi_name

# In[120]:

name_df = name_df.replace('NaN', np.nan, regex = True)


# In[159]:

# http://stackoverflow.com/questions/17165340/using-pandas-to-create-dataframe-with-series-resulting-in-memory-error
df = (name_df.apply(missing_values, axis = 0)).to_frame(name='poi_name')
df.rename(columns = {'poi_name': 'missing_count'}, inplace=True)


# In[164]:

df[df['missing_count'] > 17]


# In[130]:

poi_df[poi_df['poi_name']== 'LOCKHART EUGENE E']


# In[165]:

poi_df[poi_df['poi_name'] == 'GRAMM WENDY L']


# In[166]:

poi_df[poi_df['poi_name'] == 'WHALEY DAVID A']


# In[167]:

poi_df[poi_df['poi_name'] == 'WROBEL BRUCE']


# The Travel Agency in the Park is definitely not a POI, and so can be removed. Locahart is a Non-POI, but this person has no record at all. I will keep the other 2 persons because the dataset is already very small in size

# In[ ]:



