#!/usr/bin/python
import sys
import pickle
sys.path.append("../tools/")
import pandas as pd
from time import time
import numpy as np

from feature_format import featureFormat, targetFeatureSplit
from tester import dump_classifier_and_data, test_classifier
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.pipeline import make_pipeline
from sklearn.grid_search import GridSearchCV
from sklearn.cross_validation import train_test_split, StratifiedShuffleSplit, StratifiedKFold
from sklearn.metrics import classification_report
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.decomposition import PCA
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

### Task 1: Select what features you'll use.
### features_list is a list of strings, each of which is a feature name.
### The first feature must be "poi".

### Post a count of missing values, I have removed 5 more features
### deferral_payments, deferred_income, director_fees, loan_advances, restricted_stock_deferred
### Also includes the new feature - incentive
features_list = ['poi', 
 'salary',
 'to_messages',
 'total_payments',
 'exercised_stock_options',
 'bonus',
 'restricted_stock',
 'deferred_income',
 'shared_receipt_with_poi',
 'total_stock_value',
 'expenses',
 'deferral_payments', 
 'loan_advances',  
 'director_fees',
 'restricted_stock_deferred',
 'from_messages',
 'other',
 'from_this_person_to_poi',
 'long_term_incentive',
 'from_poi_to_this_person'
 ] 


### Load the dictionary containing the dataset
### Convert dictionary to pandas data frame
with open("final_project_dataset.pkl", "r") as data_file:
    data_dict = pickle.load(data_file)
    poi_df = pd.DataFrame.from_dict(data_dict, orient='index'). \
    reset_index(). \
    rename(columns = {'index': 'poi_name'})

### Task 2: Remove outliers
### Outliers pertaining to unusal poi_names will be dropped
### Based on my exploratory analysis, I have identified the following poi's
### ['TOTAL', 'THE TRAVEL AGENCY IN THE PARK', 'LOCKHART EUGENE E'
### 'GRAMM WENDY L', 'WHALEY DAVID A', 'WROBEL BRUCE']
### Drop [email_address]
### will be dropped
drop_list = ['email_address', 
#             'deferral_payments', 
#             'loan_advances',  
#             'director_fees',
#             'restricted_stock_deferred'
             ]
           
poi_new_df = poi_df.drop(drop_list, inplace=False, axis=1)

## reset the index before removing rows
poi_new_df.set_index('poi_name', inplace=True)

drop_pois = ['TOTAL', 
             'THE TRAVEL AGENCY IN THE PARK', 
             'LOCKHART EUGENE E',
#            'GRAMM WENDY L', 
#            'WHALEY DAVID A', 
#            'WROBEL BRUCE'
            ]
poi_new_df.drop(drop_pois, inplace=True, axis=0)
poi_new_df = poi_new_df.reset_index()
#poi_new_df.drop(['poi_name'], inplace=True, axis=1)
print 'Dimension of the new data set', poi_new_df.shape

#print 'Proportion of POI=1 class is', 1.0 * len(poi_new_df[poi_new_df['poi'] == 1]) / len(poi_new_df['poi'])
#print 'Proportion of POI=0 class is', 1.0 * len(poi_new_df[poi_new_df['poi'] == 0]) / len(poi_new_df['poi'])

'''
### Since the POI=1 class is underrepresented, let us oversample the underrepresented
### class
POI_1 = poi_new_df[poi_new_df['poi'] == 1]
POI_0 = poi_new_df[poi_new_df['poi'] == 0]

percentage = len(POI_1) / float(len(POI_0))
print len(POI_1), len(POI_0)
num_samples = len(POI_0) - len(POI_1)
print num_samples
POI_1 = POI_1.sample(n=num_samples, random_state = 42)

poi_sampled = POI_1.append(POI_0)

print "Percentage of POI=0                 :", len(POI_0) / float(len(poi_sampled))
print "Percentage of POI=1                :", len(POI_1) / float(len(poi_sampled))
print "Total number of POIs in our new dataset :", len(poi_sampled)
'''

### Task 3: Create new feature(s)
### Compute ratio of bonus to salary. i.e. for every dollar earned what was
### the bonus payout. Replace NaN's with 0
def compute_incentive(row):
    '''
    For each poi compute the ratio of bonus/salary
    Input: a row of the data frame
    Output: return the incentive
    '''
    incentive = 0.
    if row['salary'] == 'NaN':
        row['salary'] = 0.0
        return incentive
    if row['bonus'] == 'NaN':
        row['bonus'] = 0.0
    incentive = round(1.0 * row['bonus'] / row['salary'], 2)
    return incentive

poi_new_df['incentive'] = poi_new_df.apply(compute_incentive, axis=1) 
print 'Maximum incentive is', poi_new_df['incentive'].max()
print 'Who is the poi with maximum incentive? Is he/she a POI?\
', poi_df.ix[poi_new_df[poi_new_df['incentive'] == 24.53].index[0], 'poi_name'],
print  poi_df.ix[poi_new_df[poi_new_df['incentive'] == 24.53].index[0], 'poi']

features_list += ['incentive']
 
def compute_frac_mesg_to_poi(row):
    '''
    For each poi compute the fraction of messages
    from_this_person_to_poi
    '''
    if row['from_messages'] == 'NaN':
        return 0.0
    if row['from_this_person_to_poi'] == 'NaN':
        row['from_this_person_to_poi'] == 0.0
    return 1.0 * row['from_this_person_to_poi'] / row['from_messages']

poi_new_df['prop_to_poi'] = poi_new_df.apply(compute_frac_mesg_to_poi, axis=1)
#print poi_new_df['prop_to_poi'].head()

features_list += ['prop_to_poi']
   
### Store to my_dataset for easy export below.
### Convert the pandas df to dict
my_data_dict = {}   
for _, row in poi_new_df.iterrows():
    my_data_dict[row['poi_name']] = {}
    for feature in features_list:
        my_data_dict[row['poi_name']][feature] = row[feature]        
print 'Number of POIs in the new dictionary is', len(my_data_dict)
print 'Length of each POI record is', len(my_data_dict.values()[0])
#sys.exit(0) 
#data_dict = poi_new_df.set_index('poi_name').to_dict() 
my_dataset = my_data_dict
#print my_dataset

### Extract features and labels from dataset for local testing
data = featureFormat(my_dataset, features_list, sort_keys = True)
labels, features = targetFeatureSplit(data)
print 'Proportion of POI=1 classes', 1.0 * sum(1 for i in labels if i == 1) / len(labels)
print 'Proportion of POI=0 classes', 1.0 * sum(1 for i in labels if i == 0) / len(labels)


### Task 4: Try a varity of classifiers
### Please name your classifier clf for easy export below.
### Note that if you want to do PCA or other multi-stage operations,
### you'll need to use Pipelines. For more info:
### http://scikit-learn.org/stable/modules/pipeline.html
exclude_poi_list = features_list[1:] 

classifier_dict = {
                   'NB': GaussianNB(),
                   'DTC': DecisionTreeClassifier(random_state=42),
                   'RFC': RandomForestClassifier(random_state=42),
                   }

strat_shuff = StratifiedShuffleSplit(labels, n_iter=100, random_state=42)

def build_pipe(classifier, pca=False):
    '''
    helper function to create pipeline
    for different estimators
    Args: 
    classifier - type of classifier used
    pca - default value False
    Returns a Pipeline object instance
    '''
    if classifier == classifier_dict['NB']:
        if not pca:
            return make_pipeline(
#                            MinMaxScaler(),
                            SelectKBest(),
                            classifier
                            )                            
        return make_pipeline(
                MinMaxScaler(),
                SelectKBest(),
                PCA(),
                classifier
                )
    elif classifier == classifier_dict['DTC']:
        if not pca:
            return make_pipeline(
                            SelectKBest(),
                            classifier
                            )
        return make_pipeline(
                            SelectKBest(),                            
                            PCA(),
                            classifier
                            )
    else:
        if not pca:
            return make_pipeline(
                            SelectKBest(),
                            classifier
                            )
        return make_pipeline(
                            SelectKBest(),                            
                            PCA(),
                            classifier
                            )
                            
                        
def get_best_estimator(pipe, params, score_method='f1_weighted', cv=strat_shuff, verbose=0):
    '''
    helper function to fit and validate model
    with optimal parameters
    Args - Pipe object, 
          param grid for estimator - paramaters used by estimators, 
          scoring - method to score the model, 
          cross validation method - to validate the modelt,
          verbose - default is None
    Returns instance of best fit and instance of optimal grid search
    ''' 
    gs = GridSearchCV(
            pipe,
            param_grid=params,
            scoring=score_method,
            cv=cv,
            verbose=verbose
            ) 
    gs.fit(features, labels)
    clf = gs.best_estimator_
    return clf, gs



### Task 5: Tune your classifier to achieve better than .3 precision and recall 
### using our testing script. Check the tester.py script in the final project
### folder for details on the evaluation method, especially the test_classifier
### function. Because of the small size of the dataset, the script uses
### stratified shuffle split cross validation. For more info: 
### http://scikit-learn.org/stable/modules/generated/sklearn.cross_validation.StratifiedShuffleSplit.html

use_pca = False
pca_comp = [2, 3, 4]
  
k = range(1, len(my_data_dict.values()[0]))

pca_params = {'pca__n_components': pca_comp, 
              'pca__whiten': [True]
              }
kbest_params = {
        'selectkbest__k': k,
        'selectkbest__score_func': [f_classif]
        }
dt_params = {
            'decisiontreeclassifier__min_samples_split': range(10, 50, 5),
            'decisiontreeclassifier__criterion': ["gini", "entropy"],
         }  

rf_params = {
            'randomforestclassifier__min_samples_split': range(10, 50, 5),
            'randomforestclassifier__n_estimators': range(8, 15, 2),
            'randomforestclassifier__warm_start': [False, True],
            'randomforestclassifier__criterion': ['gini', 'entropy']
            }         
                    
for k, v in classifier_dict.items():
    params = {}
#    kbest = SelectKBest()
    params.update(kbest_params)
    if k == 'DTC':
        params.update(dt_params)
        if not use_pca:
            pipe = build_pipe(v)
        else:
            kbest_params['selectkbest__k'] = range(4, len(my_data_dict.values()[0]))
            params.update(kbest_params)
            pipe = build_pipe(v, use_pca)   
            params.update(pca_params)
        best_estimator, gs = get_best_estimator(pipe, 
                                                params, 
#                                                score_method='f1_weighted', 
                                                cv=strat_shuff, 
                                                verbose=0) 
        importances = gs.best_estimator_.named_steps['decisiontreeclassifier'].feature_importances_
        ind = np.argsort(importances)[::-1]
        
        print 'For Decision Tree Classifier...'
        for i in ind:
            print exclude_poi_list[i], importances[i]
        
        best_k = gs.best_estimator_.named_steps['selectkbest']    
        k_scores = [score for score in best_k.scores_]
        features_selected_bool = best_k.get_support(indices=True)
        print features_selected_bool
        features_selected_list = [(exclude_poi_list[i], k_scores[i]) for i in features_selected_bool]
        print 'Best features selected are', features_selected_list  
    
    pred = gs.predict(features)
##    target_names = ['0', '1']
##    print classification_report(labels, pred)

    clf = best_estimator
    t0 = time()
    test_classifier(clf, my_dataset, features_list, folds=1000)
    print 'Time to pass through the tester.py script is %0.3f' %(time() - t0)
'''  
    elif k == 'NB':
#        preprocess = MinMaxScaler()
        ## the below conditional statement should be 
        ## uncommented when testing for PCA; ideally
        ## this argument use_pca should be passed
        ## from the command line
        if not use_pca:
            print 'does it'
            pipe = build_pipe(v)
        else:
            ## update the range for k
            kbest_params['selectkbest__k'] = range(4, len(my_data_dict.values()[0]))
            params.update(kbest_params)
            pipe = build_pipe(v, use_pca)   
            params.update(pca_params)
        best_estimator, gs = get_best_estimator(pipe, 
                                                params, 
#                                                score_method='f1_weighted', 
                                                cv=strat_shuff, 
                                                verbose=0)                                  
        print 'For Gaussian Naive Bayes...'
        best_k = gs.best_estimator_.named_steps['selectkbest']
        print 'Number of selected best features:', gs.best_params_['selectkbest__k']
        k_scores = [score for score in best_k.scores_]
        features_selected_bool = best_k.get_support(indices=True)
        print features_selected_bool
        features_selected_list = [(exclude_poi_list[i], k_scores[i]) for i in features_selected_bool]
        print 'Best features selected are', features_selected_list    

        elif k == 'RFC':
            params.update(rf_params)
        if not use_pca:
            pipe = build_pipe(v)
        else:
            kbest_params['selectkbest__k'] = range(4, len(my_data_dict.values()[0]))
            params.update(kbest_params)
            pipe = build_pipe(v, use_pca)   
            params.update(pca_params)
        best_estimator, gs = get_best_estimator(pipe, 
                                                params, 
#                                               score_method='f1_weighted', 
                                                cv=strat_shuff, 
                                                verbose=0) 
        importances = gs.best_estimator_.named_steps['randomforestclassifier'].feature_importances_
        ind = np.argsort(importances)[::-1]
        
        print 'For Random Forest Classifier...'
        for i in ind:
            print exclude_poi_list[i], importances[i]
        
        best_k = gs.best_estimator_.named_steps['selectkbest']    
        k_scores = [score for score in best_k.scores_]
        features_selected_bool = best_k.get_support(indices=True)
        print features_selected_bool
        features_selected_list = [(exclude_poi_list[i], k_scores[i]) for i in features_selected_bool]
        print 'Best features selected are', features_selected_list  
'''        

                
#strat_kfold = StratifiedKFold(labels_train, shuffle=True, n_folds=10, random_state=42) 


### Task 6: Dump your classifier, dataset, and features_list so anyone can
### check your results. You do not need to change anything below, but make sure
### that the version of poi_id.py that you submit can be run on its own and
### generates the necessary .pkl files for validating your results.

dump_classifier_and_data(clf, my_dataset, features_list)